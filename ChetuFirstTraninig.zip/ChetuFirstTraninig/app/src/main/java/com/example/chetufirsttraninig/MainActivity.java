package com.example.chetufirsttraninig;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;

public class MainActivity extends AppCompatActivity {
    String _tag = "TAG";

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.d(_tag, "onCreate()");
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.d(_tag, "onStart()");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d(_tag, "onResume()");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.d(_tag, "onPause()");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.d(_tag, "onStop()");
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Log.d(_tag, "onRestart()");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d(_tag, "onDestroy()");
    }
}
